$('.carousel').carousel({
    pause: "none"
});
